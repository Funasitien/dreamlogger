# DreamLogger
## An fast and easy way to make your logs *fancy ✨*